import React from 'react';
import { View, Text, Button,Touchable, StyleSheet,Image,TextInput,Alert,AsyncStorage,Linking, TouchableOpacity,ActivityIndicator,Route } from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator,createAppContainer } from '@react-navigation/stack';
import forgotPassword from './details';
import selectCompany from './selectCompany';
import AppPage from '../App';
import HomePage from './home';
import payslip from './payslip';
import attendence from './attendance'; 
import CompanyList from './companyList';
import profile from './profile';
import setting from './setting';
import changePassword from './changePassword';
import employeeList from './employeeList';
import companies from './companies';
import DropDownPicker from 'react-native-dropdown-picker';
// import Icon from 'react-native-vector-icons/Feather';
import Spinner from 'react-native-loading-spinner-overlay';
import FontAwesome, { SolidIcons, RegularIcons, BrandIcons } from 'react-native-fontawesome';
import Icon from 'react-native-vector-icons/FontAwesome';

const Stack = createStackNavigator();
const MainScreen = ({navigation}) => {

  let load=true;
    const [data, setData] = React.useState({
      username: '',   
      password: '',
      check_textInputChange: false,
      secureTextEntry: true,
      isValidUser: true,
      isValidPassword: true,
      dataBase:'sandboxpre',
      icon:'eye-slash',
      isloading:false
    });
    

    const [loading, setLoading] = React.useState();
   
    const textInputChange = (val) => {
      console.log("USER Name ===",val);
      if( val.trim().length >= 1 ) {
          setData({
              ...data,
              username: val,
              check_textInputChange: true,
              isValidUser: true
          });
      } else {
          setData({
              ...data,
              username: val,
              check_textInputChange: false,
              isValidUser: false
          });
      }
    }

    const dataBaseChange = (val) => {
      console.log("DataBase Name ===",val);
      if( val.length >= 1 ) {
          setData({
              ...data,
              dataBase: val,
              check_textInputChange: true,
              isValidUser: true
          });
      } else {
          setData({
              ...data,
              username: val,
              check_textInputChange: false,
              isValidUser: false
          });
      }
    }
    
    const handlePasswordChange = (val) => {
      if( val.trim().length >= 1 ) {
          setData({
              ...data,
              password: val,
              isValidPassword: true
          });
      } else {
          setData({
              ...data,
              password: val,
              isValidPassword: false
          });
      }
    }
    
    const updateSecureTextEntry = () => {
      console.log("DATAs === ",data.secureTextEntry," ICOn === ",data.icon);
          setData({
              ...data,
              secureTextEntry: !data.secureTextEntry
              
          });

          if(data.secureTextEntry ==true){
            data.icon ='eye'
          }else{
            data.icon ='eye-slash'
          }
          console.log("Icon == ",data.icon)
    }

    const stop=()=>{
      
      console.log("START 11......",load);
   
      setData({
        ...data,
        isloading: false,
      
    });
      console.log("START......",load);

    }
    const loginHandle = (userName,Password) => {

    console.log("User Nameee == ",data.username," Password === ",data.password,"Data Base === ",data.dataBase);
        if ( data.username.length == 0 || data.password.length == 0 || data.dataBase.length ==0) {
            Alert.alert('Wrong Input!', 'Username or password field cannot be empty.', [
                {text: 'Okay'}
            ]);
            // this.state.spinner =true;
            return;
        }else{
   
          let input =data.username;
          let fields = input.split('/');
          let prefix = fields[0].toLocaleLowerCase();
          let name = fields[1];
         console.log("Prefix === ",prefix," Name  === ",name);

         if(prefix=='dns' || prefix=='live' || prefix=='sandboxpre' || prefix=='sandbox' && name){
          setData({
            ...data,
            isloading: true,
          
        });
              //  let url ="http://"+data.dataBase+".nomismasolution.co.uk/AccountREST/AccountService.svc/dns/Authorise?LoginName="+data.username+"&Password="+data.password;  
              
             let url ="http://"+prefix+".nomismasolution.co.uk/AccountREST/AccountService.svc/"+prefix+"/AuthoriseApp?LoginName="+name+"&Password="+data.password;  

              console.log("Url === ",url);
                fetch(url, {
                    method: 'GET',
                    //Request Type 
                })
                .then((response) => response.json())
                .then((responseJson) => {
                  setData({
                    ...data,
                    isloading: false,
                  
                });
                    var SampleArray =responseJson ;
                   console.log('Array ',SampleArray);
                    if(SampleArray.IsSuccess==true){

                    AsyncStorage.setItem('userDetails',JSON.stringify(SampleArray.ResultInfo));
                     AsyncStorage.setItem('urlPrefix',prefix);
                    // AsyncStorage.setItem('urlPrefix','sandboxpre');

                    navigation.navigate('companies');

                    }else{
                        Alert.alert('Wrong Input!', 'Please fill the correct user name or password.', [
                            {text: 'Okay'}
                        ]);
                    }
                    console.log("Result == ",SampleArray.IsSuccess);
                })
                //If response is not in json then in error
                .catch((error) => {
                  console.log("Error === ",error);
                  setData({
                    ...data,
                    isloading: false,
                  
                });
                    Alert.alert('Wrong Input!', 'Something went wront.', [
                        {text: 'Okay'}
                    ]);
                    // console.error(error);
                });

              }else{
                Alert.alert('Wrong Input!', 'Please enter a valid prefix and user name.', [
                  {text: 'Okay'}
              ]);

              }

        } 
       
    }
    
      return (
        // My Code
        
            <View style={styles.container}>
                <Image style={styles.tinyLogo} source={require("../images/icon.png")} />
               <Text style={{ fontSize:16, color:"#43a1a2"}}>Payroll</Text>
      
              <View all={0}>
                 <ActivityIndicator animating={data.isloading} color="#43a1a2"   size="large" />
             </View>
      
       {/* <DropDownPicker 
                  items={[  
                      {label: 'Sandbox Pre', value: 'sandboxpre', icon: () => <Icon name="briefcase" size={18} color="#fff" />},
                      {label: 'Dns', value: 'dns', icon: () => <Icon name="briefcase" size={18} color="#fff" />},
                      {label: 'Nomisma', value: 'live', icon: () => <Icon name="briefcase" size={18} color="#fff" />},
                  ]}
                  defaultValue={data.dataBase}
                  containerStyle={{height: 40, width: "80%", }}
                  style={{backgroundColor: '#43a1a2',}}
                  itemStyle={{
                      justifyContent: 'flex-start'
                  }}
                  dropDownStyle={{backgroundColor: '#a1a2a2'}}
                  onChangeItem={(item) =>dataBaseChange(item.value)} 
              /> */}
        
           <TextInput
              onChangeText={(val) => textInputChange(val)}
               style={styles.input}
              placeholder="User Name"
            />
           
           <View style={styles.textBoxcontainer}>
            <TextInput
                     style={styles.input}
                    placeholder="Password"
                    secureTextEntry={data.secureTextEntry ?true : false}
                    onChangeText={(val) => handlePasswordChange(val)}
                  />

                  <TouchableOpacity  style={styles.thouchablebtn}
                    onPress={updateSecureTextEntry}
                  >
                    {data.secureTextEntry ?
              <Icon name='eye-slash' size={18} color="#a1a1a1" />
              // <FontAwesome icon={SolidIcons.smile} />

                     :
                     <Icon name='eye'  size={18} color="#a1a1a1" />
                    // <FontAwesome icon={SolidIcons.smile} />

                    }
                  </TouchableOpacity>

           </View>


                   
                  <TouchableOpacity style={styles.log_btn} onPress={() => {loginHandle(data.username, data.password )}} >
                <Text style={styles.btn_text}>Login</Text>
                </TouchableOpacity>
           <Text style={{marginVertical:10, color:"#828282", textDecorationLine: 'underline'}}  onPress={()=> navigation.navigate('FrgotPassword')}>Forgot Password?</Text>

           <Text style={{ color:"#828282"}} onPress={()=> Linking.openURL('https://www.nomismasolution.co.uk/trynomisma')}> 
          Don't have an account yet? <Text style={{fontWeight:'bold', color:"#727274", textDecorationLine: 'underline' }}>Sign up</Text>
          </Text>
           
        </View>  
      );
    };
    
    const Login = () => {

      
        return(
        <NavigationContainer>
           <Stack.Navigator>
             <Stack.Screen name="Login" options={{headerShown: false}} component={MainScreen} />
             <Stack.Screen name="FrgotPassword" options={{headerShown: false,  }} component={forgotPassword} />
             <Stack.Screen name="SelectCompany"  component={selectCompany} />
             <Stack.Screen name="AppPage" component={AppPage} />
             <Stack.Screen name="HomePage" options={{headerShown: false}} component={HomePage} />
             <Stack.Screen name="CompanyList" options={{title: 'Choose Company',headerTintColor: 'white', headerLeft: null,headerStyle: {backgroundColor: '#43a1a2', color:'#ffffff',headerTitleAlign:'center' }}} component={CompanyList}/>
             <Stack.Screen name="payslip" options={{ title: 'Payslip',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={payslip} />
             <Stack.Screen name="attendence" options={{ title: 'Annual Leave',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={attendence}/>
             <Stack.Screen name="profile" options={{ title: 'Profile',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={profile}/>
             <Stack.Screen name="setting" options={{ title: 'Settings',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={setting}/>
             <Stack.Screen name="Change_Password" options={{ title: 'Change Password',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={changePassword}/> 
             <Stack.Screen name="employeeList" options={{ title: 'Employees',headerTintColor: 'white', headerStyle: {backgroundColor: '#43a1a2', } }} component={employeeList}/>
             <Stack.Screen name="companies" options={{title: 'Choose Company',headerTintColor: 'white', headerLeft: null,headerStyle: {backgroundColor: '#43a1a2',  }}} component={companies}/>

          </Stack.Navigator>  
        </NavigationContainer>
        )
    }

export default Login;




const styles = StyleSheet.create({

  spiner: {
    flex: 1,
    justifyContent: "center",
  },
  horizontal: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 10
  },
  container:{
    // backgroundColor: '#43a1a2',
    backgroundColor: '#fff',

    flex:1,
    justifyContent:'center',
    alignItems:'center',

    
  },
  welcometext:{
    color:'#fff',
    fontSize:18,
  },
    inputext: {
      width: 200,
      height: 44,
      padding: 10,
      textAlign:'center',
      fontWeight:'bold',
      borderWidth: 1,
      borderColor: 'black',
      marginBottom: 10,
    },
    input: {
      width:"80%",
      backgroundColor:'#eee',
      borderRadius:5,
      paddingLeft:10,
      marginVertical:10,
      fontSize:16,
      color:'#000',
      height:40,
      alignItems:'stretch',
    },
   
    login:{
      margin: 2,
      paddingBottom:3 ,
    },   
    stop:{
      margin: 3,
      paddingBottom:2 ,
    },
    tinyLogo: {
      width: 100,
      height: 100,
      marginBottom:0,
    },
    spinnerTextStyle: {
        color: '#FFF'
      },
      button:{
        width: 300,
        margin: 14
      },
      signup:{
        textAlign: "center"
      },
      
      log_btn:{
        width:"80%",
        backgroundColor:"#43a1a2",
        borderRadius:5,
        paddingVertical:10,
        marginVertical:10,
        fontSize:20,
        height:45,
        borderWidth:null,
        textAlign:'center',
        
      },
      
      btn_text:{
        color:'#ffffff',
        fontWeight:'300',
        textAlign:'center',
        fontSize:18,
      },
    
      textBoxcontainer:{
        width:"100%",
      position:'relative',
      alignItems:'center',
      justifyContent:'center',
      },
    
      thouchablebtn:{
       position:'absolute', 
       right:35,
       width:35,
       height:40,
       padding:2,
       paddingVertical:10,
      },
  });