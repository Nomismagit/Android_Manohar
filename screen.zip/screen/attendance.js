import React, { Component } from 'react';
import { View, Text, FlatList, ActivityIndicator,AsyncStorage, ScrollView ,Linking, StyleSheet} from 'react-native';
import { ListItem, SearchBar } from 'react-native-elements';

class FlatListDemo extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      data: [],
      error: null,
      page:1
    };

    this.arrayholder = [];
  }

  componentDidMount() {
    // this.makeRemoteRequest();
    console.log("Hello World");
    this.testScrolling(this.state.page);
  }

  scrollViewr =()=>{
    this.setState({
      page:this.state.page +1
    })
    console.log("Scrolling is working",this.state.page + 1);
    this.testScrolling(this.state.page + 1);
  }

 

  testScrolling =(pagenum)=>{
    // const url ="http://integralites.com/app/apis/eBook.php";

    AsyncStorage.getItem('urlPrefix').then(ress => {
      AsyncStorage.getItem('userDetails').then(res => {
        AsyncStorage.getItem('companyCode').then(compCod => {
        var result = new Array();
        result =JSON.parse(res);
        let code =compCod
console.log("PreFix === ",ress," code = ",code);
      // const url = "http://"+ress+".nomismasolution.co.uk/AccountREST/AccountService.svc/"+ress+"/"+ result.AuthToken +"/"+result.UserCode+"/4/GetPaySlipListApp?Page="+pagenum+"&Limit=12";
      const url = "http://"+ress+".nomismasolution.co.uk/AccountREST/AccountService.svc/"+ress+"/"+ result.AuthToken +"/"+result.UserCode+ "/4/GetEmployeeLeaveListApp?Page="+pagenum+"&Limit=12";

    console.log("Url === ",url," PAGE ===== ",pagenum);
                  fetch(url, {
                    method: 'GET',
                    //Request Type 
                })
                .then((response) => response.json())
                .then((responseJson) => { 
                  console.log("Response JSON === ",responseJson);
                  this.setState({loading:false});
                  if(pagenum ==1){
                    console.log("IF COndition ==================================",responseJson.ResultInfo.length);
                    if(responseJson.ResultInfo.length > 0){
                      this.setState({
                        data: responseJson.ResultInfo,
                        loading:false
                        // error: responseJson.error || null,
                        // loading: false,
                      });
                    }else{
                     

                    }
                  
                }else{
                  console.log("ELSe COndition");
                  this.setState({
                    data: this.state.data.concat(responseJson.ResultInfo),
                    // error: responseJson.error || null,
                     loading: false,
                  });
                }
              });
                });      
              });
            });    
  }

  makeRemoteRequest = () => {

    AsyncStorage.getItem('urlPrefix').then(ress => {
    AsyncStorage.getItem('userDetails').then(res => {
          var result = new Array();
          result =JSON.parse(res);

    const url = "http://"+ress+".nomismasolution.co.uk/AccountREST/AccountService.svc/"+ress+"/"+ result.AuthToken + "/4/GetEmployeeLeaveListApp?Page="+pagenum+"&Limit=12";
    
    this.setState({ loading: true });
    fetch(url)
      .then(res => res.json())
      .then(res => {
        console.log("RES  === ",res);
        this.setState({
          data: res.ResultInfo,
          error: res.error || null,
          loading: false,
        });
        this.arrayholder = res.ResultInfo;
      })
      .catch(error => {
        this.setState({ error, loading: false });
      });

     });
   });
  };

  renderSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: '86%',
          backgroundColor: '#CED0CE',
          marginLeft: '14%',
        }}
      />
    );
  };

  searchFilterFunction = text => {
    this.setState({
      value: text,
    });

    const newData = this.arrayholder.filter(item => {
      const itemData = `${item.CompanyName}`;
      const textData = text.toUpperCase();

      return itemData.indexOf(text) > -1;
    });
    this.setState({
      data: newData,
    });
  };


  renderHeader = () => {
    return (
      <SearchBar
        placeholder="Type Here..."
        lightTheme
        round
        onChangeText={text => this.searchFilterFunction(text)}
        autoCorrect={false}
        value={this.state.value}
      />
    );
  };

  render() {
    // if (this.state.loading) {
    //   return (
    //     <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
    //       <ActivityIndicator />
    //     </View>
    //   );
    // }
    return (

      <View style={{ flex: 1 }}>

      {this.state.data ==0? 
      <Text style={styles.error}>No Record Found</Text>
      :null}
        <ActivityIndicator animating={this.state.loading} color="#43a1a2"   size="large" />    
        <FlatList
          data={this.state.data}
          renderItem={({ item }) => (
            <ListItem 
            onPress={()=> Linking.openURL(item.PaySlipPath)}
            // onPress={() =>this.setCompanyCode(item)}
              // leftAvatar={{ source: { uri: item.picture.thumbnail } }}
              title={`${item.PayrollTranCode}`}
              // subtitle={item.email}
            />
          )}
          onEndReached={this.scrollViewr}
           keyExtractor={item => item.PayrollTranCode}
          ItemSeparatorComponent={this.renderSeparator}
          // ListHeaderComponent={this.renderHeader}
        />
      </View>
    );
  }
}

export default FlatListDemo;

const styles = StyleSheet.create({

  error: {
    color:"red",
    justifyContent: "center",
    textAlign:"center",
    padding:20,
    fontSize:20
  }

})