import React, { useEffect, useState } from 'react';
import { AsyncStorage } from 'react-native';
import Home from './home';
import { NavigationContainer,NavigationInjectedProps, withNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
  SectionList,
  Searchbar,
  TouchableOpacity,
  h1,
  TextInput,Button
} from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import DatePicker from 'react-native-datepicker';
import DateTimePicker from '@react-native-community/datetimepicker';

import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';

export default App = ({navigation}) => {
  const [date, setDate] = useState(new Date(1598051730000));
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);

  const [data, setData] = React.useState({
    title:'',
    firstName:'',
    lastName:'',
    gender:'',
    dob:'',
    address:'',
    postalCode:'',
    phone:'',
    email:'',
    niNumber:'',
    maxDate:new Date()
  });

  const Stack = createStackNavigator();
  const onChange = (event, selectedDate) => {
    
   const currentDate = selectedDate || date;
   let d= moment(selectedDate).format("DD-MM-YYYY");
   console.log("DATE ===== ",d," Selectable Date == ",selectedDate);
   data.dob=d;
  setShow(Platform.OS === 'ios');
  setDate(currentDate);
  };

  const showMode = (currentMode) => {
    console.log("")
    setShow(true);
    setMode(currentMode);
  };

  const showDatepicker = () => {
    showMode('date');
  };

  const showTimepicker = () => {
    showMode('time');
  };

  useEffect(() => {
    var result = new Array(); 
    AsyncStorage.getItem('urlPrefix').then(ress => {

    AsyncStorage.getItem('userDetails').then(res => {
        var result = new Array();
        result =JSON.parse(res);

    const url = "http://"+ress+".nomismasolution.co.uk/AccountREST/AccountService.svc/"+ress+"/"+ result.AuthToken+"/"+result.UserCode+"/4/GetUserDetailsListApp";
    console.log("URL ===== ",url);
    fetch(url)
      .then((response) => response.json())
      .then((json) =>{
      console.log("User details === ",json);
      setData(json.ResultInfo)
      
      })
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));

    })
    })
  }, []);

  const profileUpdate = () => {
  
    console.log("DATA === ",data);
}

const validateEmail =(email)=>{
  var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(email);
}

const dateSet = (date) => {
  
  console.log("Date === ",date);
}



  return (
   <View>
     <ScrollView>

    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Title:</Text>
    <DropDownPicker
                  items={[  
                      {label: 'Mr.', value: 'mr', icon: () => <Icon name="user" size={18} color="#43a1a2" />},
                      {label: 'Mrs.', value: 'mrs', icon: () => <Icon name="user" size={18} color="#43a1a2" />},
                      {label: 'Miss', value: 'miss', icon: () => <Icon name="user" size={18} color="#43a1a2" />},
                      {label: 'Ms.', value: 'ms', icon: () => <Icon name="user" size={18} color="#43a1a2" />},
                      {label: 'Dr', value: 'dr', icon: () => <Icon name="user" size={18} color="#43a1a2" />},
                  ]}
                  defaultValue='mr'
                  containerStyle={{height: 40,width:225,marginLeft:30, marginVertical:15,}}
                  style={{backgroundColor: '#fafafa'}}
                  itemStyle={{
                      justifyContent: 'flex-start'
                  }}
                  dropDownStyle={{backgroundColor: '#fafafa'}}
                   onChangeItem={(item) =>data.title =item.value} 
              />
    </View> 
    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>First Name:<Text style={{ color: 'red' }}>*</Text></Text>
    <TextInput  underlineColorAndroid='rgba(0,0,0,0)' placeholder='First Name'  style={styles.inputBox}
    onChangeItem={(item) =>data.firstName =item.value} 
    maxLength={30}
    />
    </View>
    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Last Name:<Text style={{ color: 'red' }}>*</Text></Text>
    <TextInput style={styles.inputBox} underlineColorAndroid='rgba(0,0,0,0)' placeholder='Last Name'  maxLength={30} />
    </View>
    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Gender:<Text style={{ color: 'red' }}>*</Text></Text>
    <DropDownPicker
                  items={[  
                      {label: 'Male', value: 'm', icon: () => <Icon name="mars" size={18} color="#43a1a2" />},
                      {label: 'Female', value: 'f', icon: () => <Icon name="venus-double" size={18} color="#43a1a2" />},
                      // {label: 'Other', value: 'o', icon: () => <Icon name="genderless" size={18} color="#900" />},
                  ]}
                  defaultValue='m'
                  containerStyle={{height: 40,width:225,marginLeft:30, marginVertical:15, }}
                  style={{backgroundColor: '#fafafa'}}
                  itemStyle={{
                      justifyContent: 'flex-start'
                  }}
                  dropDownStyle={{backgroundColor: '#fafafa'}}
                   onChangeItem={(item) =>data.gender =item.value} 
              />
    </View>

    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>DOB:<Text style={{ color: 'red' }}>*</Text></Text>
    
      <View style={styles.inputBox}><Text style={{paddingVertical:10}}>{data.dob}</Text> 
        <View style={styles.thouchablebtn}><Icon name='calendar'  onPress={showDatepicker}  size={18} color="#a1a1a1" /></View>
      </View>
     
      {show && (
        <DateTimePicker
          testID="dateTimePicker"
          value={date}
          mode={mode}
          is24Hour={true}
          display="default"
           onChange={onChange}
           maximumDate={new Date()}
        />
      )}
   
   </View>
   
    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth} >Address:<Text style={{ color: 'red' }}>*</Text></Text>
    <TextInput maxLength={30} style={styles.inputBox} onChangeItem={(item) =>data.address =item.value} placeholder="Address" underlineColorAndroid='rgba(0,0,0,0)'  />
    </View>
    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}></Text>
    <TextInput  maxLength={30} style={styles.inputBox} onChangeItem={(item) =>data.city =item.value} placeholder='City' onChangeItem={(item) =>data.city =item.value} underlineColorAndroid='rgba(0,0,0,0)'  />
    </View>

    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}></Text>
    <TextInput  maxLength={30} style={styles.inputBox} onChangeItem={(item) =>data.state =item.value} placeholder='State' underlineColorAndroid='rgba(0,0,0,0)'  />
    </View>

    <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Post Code:<Text style={{ color: 'red' }}>*</Text></Text>
    <TextInput maxLength={7} placeholder='Postal Code' onChangeItem={(item) =>data.postalCode =item.value} style={styles.inputBox} underlineColorAndroid='rgba(0,0,0,0)'  />
    </View>

  <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Phone:</Text>
    <TextInput maxLength={13} keyboardType={'phone-pad'} placeholder='Phone' onChangeItem={(item) =>data.phone =item.value} style={styles.inputBox} underlineColorAndroid='rgba(0,0,0,0)'  />
    
  
  </View>
  <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>Email:</Text>
    <TextInput placeholder='Email' onChangeItem={(item) =>data.email =item.value} style={styles.inputBox} underlineColorAndroid='rgba(0,0,0,0)'  />
  </View>
  <View style={styles.flexrow1}>
    <Text style={styles.labelwidth}>NI Number:</Text>
    <TextInput maxLength={9} style={styles.inputBox} placeholder='NI Number' onChangeItem={(item) =>data.niNumber =item.value} underlineColorAndroid='rgba(0,0,0,0)'  />
  </View>


<TouchableOpacity onPress={() =>profileUpdate()} style={styles.log_btn} >
<Text style={styles.btn_text}>Update</Text>
</TouchableOpacity>

</ScrollView>
</View>
  );
};


const styles = StyleSheet.create({
  container:{
    backgroundColor: '#ffffff',
    flexDirection:"column",
    justifyContent:'center',
    alignItems:'center',

  },
  
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor:'#007173',
    paddingVertical:30, 
    color:'#ffffff',
    fontSize:18,
    padding:15,
  },

  onebox:{
      backgroundColor:'#43a1a2',
      textAlign:"left",
      fontSize:24,
      color:'#ffffff',
      textAlignVertical:"center",
      marginBottom:1,
      justifyContent:"space-evenly",
      paddingVertical:60,
      paddingLeft:20,
  },

  coricon:{
    fontSize:16,
      color:'#ffffff',
  },

  CardItembg:{
    backgroundColor:'#43a1a2',
    marginBottom:15,
    height:70,

  },
  
card_headtext:{
  fontSize:20,
  color:'#ffffff',
  paddingLeft:15,

},

cardicon:{  fontSize:20,
  color:'#ffffff',},

headerbg:{
  backgroundColor:'#43a1a2',
},

labelwidth:{
  width:120,
  marginVertical:10,
  paddingLeft:10,
},
log_btn:{
  backgroundColor:"#43a1a2",
  borderRadius:5,
  paddingVertical:8,
  marginVertical:10,
  fontSize:20,
  justifyContent:'center',
  alignItems:'center',
  marginLeft:15,
  marginRight:15,

},

btn_text:{
  color:'#ffffff',
  fontWeight:'300',
  textAlign:'center',
  fontSize:18,
},

inputBox:{
  width:225,
  borderRadius:5,
  marginVertical:5,
  borderColor:'#ccc',
  borderWidth:1,
  
},
textBoxcontainer:{
  width:"100%",
position:'relative',
alignItems:'center',
justifyContent:'center',
},

thouchablebtn:{
 position:'absolute', 
 right:35,
 width:35,
 height:40,
 padding:2,
 paddingVertical:10,
},

flexrow1:{
flex:1,
 flexDirection:"row",
},

labelwidth:{
  width:"25%",
  marginVertical:20,
  paddingLeft:10,
  fontSize:14,
},

inputBox:{
  width:225,
  borderRadius:5,
  paddingLeft:10,
  marginVertical:10,
  fontSize:14, 
  marginLeft:30,
  height:40,
  borderColor:'#ccc',
  borderWidth:1,
  position:'relative',
  
},



thouchablebtn:{
 position:'absolute', 
 right:-4,
 width:35,
 height:40,
 padding:2,
 paddingVertical:10,
},



});


